import datetime as dtm
import time

t = dtm.time(11,-1)

print(t.hour)
print(t.minute)